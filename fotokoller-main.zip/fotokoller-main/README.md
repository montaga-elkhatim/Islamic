# fotokoller
EN: Portfolio website of my father's ex-Company

The website now has a browsable database containing some of the products
that were developed and realised in the years of the company's existence. 

After searching the Internet I found a method to filter the samples:

https://eikes.github.io/facetedsearch/

The author did a great work. My inital search for a way to filter the
samples returned only basic methods (ways to filter using only one
criterion), but that wasn't enough.

I managed to adapt the method to my needs. 

More samples will be added.
