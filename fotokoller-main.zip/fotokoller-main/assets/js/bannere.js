// Most of the time I suppose you would use jQuery to get your data; 
  /*
    $.getJSON( "http:/example.com", function(data){ 
      $.facetelize....
    });
  */
    var example_items = [
        {
            "firstname": "Oswald",
            "lastname": "Curcă",
            "imageURL": "assets\\images\\mostre\\banner\\bannerOtinekSport1-1200x240.PNG",
            "description": "Modelul 1 de banner pentru Otinek Sport - echipamente sportive",
            "category": "imprimerie sportivă",
            "year": "1999",
            "company": "Otinek-Sport",
            "backgroundColor": "crem",
            "foregroundColor": "mix",
        },
        {
          "firstname": "Oswald",
          "lastname": "Curcă",
          "imageURL": "assets\\images\\mostre\\banner\\bannerOtinekSport2-1200x240.PNG",
          "description": "Modelul 2 de banner pentru Otinek Sport - echipamente sportive",
          "category": "imprimerie sportivă",
          "year": "1999",
          "company": "Otinek-Sport",
          "backgroundColor": "alb",
          "foregroundColor": "mix",
        },
        {
          "firstname": "Oswald",
          "lastname": "Curcă",
          "imageURL": "assets\\images\\mostre\\banner\\bannerOtinekSport3-1200x240.PNG",
          "description": "Modelul 3 de banner pentru Otinek Sport - echipamente sportive",
          "category": "imprimerie sportivă",
          "year": "1999",
          "company": "Otinek-Sport",
          "backgroundColor": "ocru",
          "foregroundColor": "mix",
        },
        {
          "firstname": "Mostra",
          "lastname": "",
          "imageURL": "",
          "description": "",
          "category": "",
          "year": "",
          "company": "Foto Koller",
          "backgroundColor": "",
          "foregroundColor": "",
          "ID" : "1"
        },/*
        {
          "firstname": "Mostra",
          "lastname": "",
          "imageURL": "",
          "description": "",
          "category": "",
          "year": "",
          "company": "Foto Koller",
          "backgroundColor": "",
          "foregroundColor": "",
          "ID" : "1"
        },
        {
          "firstname": "Mostra",
          "lastname": "",
          "imageURL": "",
          "description": "",
          "category": "",
          "year": "",
          "company": "Foto Koller",
          "backgroundColor": "",
          "foregroundColor": "",
          "ID" : "1"
        },
        {
          "firstname": "Mostra",
          "lastname": "",
          "imageURL": "",
          "description": "",
          "category": "",
          "year": "",
          "company": "Foto Koller",
          "backgroundColor": "",
          "foregroundColor": "",
          "ID" : "1"
        },*/
      ];