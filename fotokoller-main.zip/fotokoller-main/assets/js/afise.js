// Most of the time I suppose you would use jQuery to get your data; 
  /*
    $.getJSON( "http:/example.com", function(data){ 
      $.facetelize....
    });
  */
    var example_items = [
        {
          "firstname": "Oswald",
          "lastname": "Curcă",
          "imageURL": "assets\\images\\mostre\\afise\\afisOtinekSport350x246.PNG",
          "description": "Afiș publicitar Otinek Sport. Atelier creație și execuție confecții textile",
          "category": "imprimerie sportivă",
          "year": "1999",
          "company": "Otinek Sport",
          "backgroundColor": "alb",
          "foregroundColor": "mix",
        },
        {
          "firstname": "Teodor",
          "lastname": "Danciu",
          "imageURL": "assets\\images\\mostre\\afise\\afis-DanciuArtHeraldic-2000-2537x473.PNG",
          "description": "Art Heraldic. Al doilea congres mondial Dracula, Poiana Braşov. Tip banner.",
          "category": "gotic",
          "year": "2000",
          "company": "Otinek Sport",
          "backgroundColor": "transparent",
          "foregroundColor": "mix",
        },
        {
          "firstname": "Teodor",
          "lastname": "Danciu",
          "imageURL": "assets\\images\\mostre\\afise\\afis-TeodorDanciu-2000-1071x1465.PNG",
          "description": "Art Heraldic. Al doilea congres mondial Dracula, Poiana Braşov. Tip afiş.",
          "category": "gotic",
          "year": "2000",
          "company": "Otinek Sport",
          "backgroundColor": "transparent",
          "foregroundColor": "mix",
        },
        {
          "firstname": "",
          "lastname": "",
          "imageURL": "",
          "description": "",
          "category": "",
          "year": "",
          "company": "Foto Koller",
          "backgroundColor": "",
          "foregroundColor": "",
        },/*
        {
          "firstname": "",
          "lastname": "",
          "imageURL": "",
          "description": "",
          "category": "",
          "year": "",
          "company": "",
          "backgroundColor": "",
          "foregroundColor": "",
        },*/
      ];