// Most of the time I suppose you would use jQuery to get your data; 
  /*
    $.getJSON( "http:/example.com", function(data){ 
      $.facetelize....
    });
  */
    var example_items = [
        {
          "firstname": "Oswald",
          "lastname": "Curcă",
          "imageURL": "assets\\images\\mostre\\anteturi\\antet-calend-Otinek-2000-925x445.png",
          "description": "pentru calendare particularizate",
          "category": "sport",
          "year": "2000",
          "company": "Otinek Sport",
          "backgroundColor": "transparent",
          "foregroundColor": "negru",
        },
        {
          "firstname": "Mostra",
          "lastname": "",
          "imageURL": "",
          "description": "",
          "category": "",
          "year": "",
          "company": "Foto Koller",
          "backgroundColor": "",
          "foregroundColor": "",
          "ID" : "1"
        },/*
        {
          "firstname": "Mostra 1",
          "lastname": "",
          "imageURL": "",
          "description": "",
          "category": "",
          "year": "",
          "company": "Foto Koller",
          "backgroundColor": "",
          "foregroundColor": "",
          "ID" : "1"
        },
        {
          "firstname": "Mostra 1",
          "lastname": "",
          "imageURL": "",
          "description": "",
          "category": "",
          "year": "",
          "company": "Foto Koller",
          "backgroundColor": "",
          "foregroundColor": "",
          "ID" : "1"
        },
        {
          "firstname": "Mostra 1",
          "lastname": "",
          "imageURL": "",
          "description": "",
          "category": "",
          "year": "",
          "company": "Foto Koller",
          "backgroundColor": "",
          "foregroundColor": "",
          "ID" : "1"
        },*/
      ];