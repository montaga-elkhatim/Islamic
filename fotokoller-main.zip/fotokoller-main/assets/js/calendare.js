// Most of the time I suppose you would use jQuery to get your data; 
  /*
    $.getJSON( "http:/example.com", function(data){ 
      $.facetelize....
    });
  */
    var example_items = [
        {
          "firstname": "Oswald",
          "lastname": "Curcă",
          "imageURL": "assets\\images\\mostre\\calendare\\calen-OtinekSport-2000-1100x782.PNG",
          "description": "pentru anul 2001",
          "category": "sport",
          "year": "2000",
          "company": "Otinek Sport",
          "backgroundColor": "crem",
          "foregroundColor": "mix",
        },
        {
          "firstname": "Oswald",
          "lastname": "Curcă",
          "imageURL": "assets\\images\\mostre\\calendare\\calen-OtinekSport-1999.svg",
          "description": "calendar sportiv",
          "category": "sport",
          "year": "1999",
          "company": "Otinek Sport",
          "backgroundColor": "crem",
          "foregroundColor": "mix",
        },
        {
          "firstname": "Oswald",
          "lastname": "Curcă",
          "imageURL": "assets\\images\\mostre\\calendare\\calen-OtinekSport-1-1500x1071-2001.png",
          "description": "calendar sportiv",
          "category": "sport",
          "year": "2000",
          "company": "Otinek Sport",
          "backgroundColor": "crem",
          "foregroundColor": "mix",
        },
        {
          "firstname": "Oswald",
          "lastname": "Curcă",
          "imageURL": "assets\\images\\mostre\\calendare\\calen-OtinekSport-2-1500x1071-2001.png",
          "altText": "Modelul 2 de calendar sportiv. Om alergând cu o torță în mâna dreaptă. Sub, un calendar.",
          "description": "calendar sportiv",
          "category": "sport",
          "year": "2000",
          "company": "Otinek Sport",
          "backgroundColor": "galben",
          "foregroundColor": "mix",
        },
        {
          "firstname": "Oswald",
          "lastname": "Curcă",
          "imageURL": "assets\\images\\mostre\\calendare\\calen-OtinekSport-3-1500x1071-2001.png",
          "description": "calendar sportiv",
          "category": "sport",
          "year": "2000",
          "company": "Otinek Sport",
          "backgroundColor": "crem",
          "foregroundColor": "mix",
        },
        {
          "firstname": "Oswald",
          "lastname": "Curcă",
          "imageURL": "assets\\images\\mostre\\calendare\\calen-OtinekSport-4-1500x1071-2001.png",
          "description": "calendar sportiv",
          "category": "sport",
          "year": "2000",
          "company": "Otinek Sport",
          "backgroundColor": "albastru",
          "foregroundColor": "mix",
        },
        {
          "firstname": "Mostra",
          "lastname": "",
          "imageURL": "",
          "description": "",
          "category": "",
          "year": "",
          "company": "Foto Koller",
          "backgroundColor": "",
          "foregroundColor": "",
          "ID" : "1"
        },/*
        {
          "firstname": "Mostra",
          "lastname": "",
          "imageURL": "",
          "description": "",
          "category": "",
          "year": "",
          "company": "Foto Koller",
          "backgroundColor": "",
          "foregroundColor": "",
          "ID" : "1"
        },
        {
          "firstname": "Mostra",
          "lastname": "",
          "imageURL": "",
          "description": "",
          "category": "",
          "year": "",
          "company": "Foto Koller",
          "backgroundColor": "",
          "foregroundColor": "",
          "ID" : "1"
        },*/
      ];