// Most of the time I suppose you would use jQuery to get your data; 
  /*
    $.getJSON( "http:/example.com", function(data){ 
      $.facetelize....
    });
  */
    var example_items = [
        {
          "firstname": "",
          "lastname": "Asociația Clubul Sportiv Școala de fotbal Valea Frumoasei",
          "imageURL": "assets\\images\\mostre\\filmeSerigrafice\\filmFotoAsocClubSportScFotValFrum-206x268.jpg",
          "description": "Film serigrafic tipărit, pentru Asociația Clubul Sportiv Școala de fotbal Valea Frumoasei.",
          "category": "sport",
          "year": "?",
          "company": "Școala de fotbal Valea Frumoasei",
        },
        {
          "firstname": "",
          "lastname": "A. S. Teaca",
          "imageURL": "assets\\images\\mostre\\filmeSerigrafice\\filmPozASTeaca-350x246.png",
          "description": "Model de film serigrafic pentru A. S. Teaca",
          "category": "sport",
          "year": "?",
          "company": "A. S. Teaca",
        },
        {
          "firstname": "Alex",
          "lastname": "Dora",
          "imageURL": "assets\\images\\mostre\\filmeSerigrafice\\filmAlexDora-350x246.PNG",
          "description": "Film serigrafic pentru Alex Dora.",
          "category": "?",
          "year": "2000",
          "company": "Alex Dora",
        },
        {
          "firstname": "",
          "lastname": "",
          "imageURL": "assets\\images\\mostre\\filmeSerigrafice\\filmAltar-800x600.PNG",
          "description": "Film serigrafic",
          "category": "religie?",
          "year": "1998",
          "company": "?",
        },
        {
          "firstname": "Oswald",
          "lastname": "Curcă",
          "imageURL": "assets\\images\\mostre\\filmeSerigrafice\\filmBuderusGuss-1500x430.PNG",
          "description": "Buderus Guss",
          "category": "?",
          "year": "2001",
          "company": "Buderus Guss",
        },
        {
          "firstname": "",
          "lastname": "",
          "imageURL": "assets\\images\\mostre\\filmeSerigrafice\\filmDekA-1998-450x119.PNG",
          "description": "DEK",
          "category": "",
          "year": "1998",
          "company": "DEK",
        },
        {
          "firstname": "",
          "lastname": "",
          "imageURL": "assets\\images\\mostre\\filmeSerigrafice\\film-Dracula-1999-660x787.PNG",
          "description": "Dracula logo",
          "category": "",
          "year": "1999",
          "company": "",
        },
        {
          "firstname": "Mostra",
          "lastname": "",
          "imageURL": "",
          "description": "",
          "category": "",
          "year": "",
          "company": "Foto Koller",
          "backgroundColor": "",
          "foregroundColor": "",
          "ID" : "1"
        },/*
        {
          "firstname": "Mostra",
          "lastname": "",
          "imageURL": "",
          "description": "",
          "category": "",
          "year": "",
          "company": "Foto Koller",
          "backgroundColor": "",
          "foregroundColor": "",
          "ID" : "1"
        },
        {
          "firstname": "Mostra",
          "lastname": "",
          "imageURL": "",
          "description": "",
          "category": "",
          "year": "",
          "company": "Foto Koller",
          "backgroundColor": "",
          "foregroundColor": "",
          "ID" : "1"
        },*/
      ];